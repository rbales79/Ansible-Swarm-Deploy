#!/bin/sh

py.test --connection=docker tests
